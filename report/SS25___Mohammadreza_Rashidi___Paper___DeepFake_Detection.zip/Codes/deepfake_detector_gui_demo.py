#!/usr/bin/env python3
"""
Deepfake Detection GUI Demo
This script demonstrates the GUI functionality without requiring heavy dependencies.
"""

import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path

class DemoGUI:
    """Demo version of the Deepfake Detection GUI"""
    
    def __init__(self, root):
        self.root = root
        self.root.title("Deepfake Detection in Social Media: A Temporal Artifact Analysis Using 3D Convolutional Neural Networks - UE University (Demo)")
        self.root.geometry("1000x650")
        
        # Modern dark theme colors
        self.colors = {
            'bg_dark': '#0d1117',
            'bg_secondary': '#161b22',
            'glass_bg': '#1c2128',
            'accent_blue': '#58a6ff',
            'accent_green': '#3fb950',
            'accent_red': '#f85149',
            'text_primary': '#f0f6fc',
            'text_secondary': '#8b949e',
            'text_muted': '#6e7681'
        }
        
        self.root.configure(bg=self.colors['bg_dark'])
        
        self.create_widgets()
    
    def create_widgets(self):
        """Create and arrange GUI widgets"""
        # Main frame
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Configure grid weights
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        
        # Title
        title_label = ttk.Label(main_frame, text="Deepfake Detection System", 
                               font=("Arial", 16, "bold"))
        title_label.grid(row=0, column=0, columnspan=3, pady=(0, 20))
        
        subtitle_label = ttk.Label(main_frame, text="3D CNN Temporal Consistency Analysis (Demo Mode)", 
                                  font=("Arial", 10, "italic"))
        subtitle_label.grid(row=1, column=0, columnspan=3, pady=(0, 20))
        
        # Demo info
        info_frame = ttk.LabelFrame(main_frame, text="Demo Information", padding="10")
        info_frame.grid(row=2, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(0, 10))
        info_frame.columnconfigure(0, weight=1)
        
        info_text = """This is a demonstration of the Deepfake Detection GUI interface.
        
The actual application requires the following dependencies:
• PyTorch (torch, torchvision) 
• OpenCV (opencv-python)
• PIL (Pillow)
• NumPy

To use the full application:
1. Install requirements: pip install -r requirements.txt
2. Run: python deepfake_detector_gui.py
3. Load a trained model (.pth file)
4. Select a video file for analysis
5. View detailed results and confidence scores"""
        
        info_label = ttk.Label(info_frame, text=info_text, justify=tk.LEFT)
        info_label.grid(row=0, column=0, sticky=(tk.W, tk.E))
        
        # Model section (disabled)
        model_frame = ttk.LabelFrame(main_frame, text="Model Loading (Demo - Disabled)", padding="10")
        model_frame.grid(row=3, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(0, 10))
        model_frame.columnconfigure(1, weight=1)
        
        ttk.Label(model_frame, text="Model File:").grid(row=0, column=0, sticky=tk.W, padx=(0, 10))
        model_entry = ttk.Entry(model_frame, state="disabled")
        model_entry.grid(row=0, column=1, sticky=(tk.W, tk.E), padx=(0, 10))
        model_btn = ttk.Button(model_frame, text="Browse", state="disabled")
        model_btn.grid(row=0, column=2)
        
        # Video section (disabled)
        video_frame = ttk.LabelFrame(main_frame, text="Video Selection (Demo - Disabled)", padding="10")
        video_frame.grid(row=4, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(0, 10))
        video_frame.columnconfigure(1, weight=1)
        
        ttk.Label(video_frame, text="Video File:").grid(row=0, column=0, sticky=tk.W, padx=(0, 10))
        video_entry = ttk.Entry(video_frame, state="disabled")
        video_entry.grid(row=0, column=1, sticky=(tk.W, tk.E), padx=(0, 10))
        video_btn = ttk.Button(video_frame, text="Browse", state="disabled")
        video_btn.grid(row=0, column=2)
        
        # Analysis section (demo)
        analysis_frame = ttk.LabelFrame(main_frame, text="Analysis (Demo)", padding="10")
        analysis_frame.grid(row=5, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(0, 10))
        
        demo_btn = ttk.Button(analysis_frame, text="Show Demo Results", command=self.show_demo_results)
        demo_btn.grid(row=0, column=0, pady=(0, 10))
        
        # Results text area
        results_frame = ttk.LabelFrame(main_frame, text="Results", padding="10")
        results_frame.grid(row=6, column=0, columnspan=3, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 10))
        results_frame.columnconfigure(0, weight=1)
        results_frame.rowconfigure(0, weight=1)
        
        self.result_text = tk.Text(results_frame, height=10, wrap=tk.WORD)
        scrollbar = ttk.Scrollbar(results_frame, orient="vertical", command=self.result_text.yview)
        self.result_text.configure(yscrollcommand=scrollbar.set)
        self.result_text.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        scrollbar.grid(row=0, column=1, sticky=(tk.N, tk.S))
        
        # Initial message
        self.result_text.insert(tk.END, "Welcome to the Deepfake Detection System Demo!\n\n")
        self.result_text.insert(tk.END, "This interface shows how the actual application works.\n")
        self.result_text.insert(tk.END, "Click 'Show Demo Results' to see sample analysis output.\n\n")
        self.result_text.insert(tk.END, "For the real application, install dependencies and run:\n")
        self.result_text.insert(tk.END, "python deepfake_detector_gui.py\n\n")
    
    def show_demo_results(self):
        """Show demo analysis results"""
        self.result_text.delete(1.0, tk.END)
        
        demo_result = """=== DEMO ANALYSIS RESULTS ===

🚨 DEEPFAKE DETECTED 🚨

Classification: FAKE
Confidence: High (87.3%)

Detailed Probabilities:
• Real: 12.7%
• Fake: 87.3%

Analysis Details:
• Frames processed: 16
• Model: 3D CNN (R3D-18)
• Method: Temporal consistency analysis
• Device: GPU (CUDA)
• Face detection: Enabled

⚠️ High confidence deepfake detection!
• Consider reporting if harmful content
• Verify with additional tools if needed
• Be cautious with sensitive applications

Technical Details:
• Video resolution: 1280x720
• Duration: 4.2 seconds
• Face detection: 16/16 frames successful
• Temporal artifacts detected: Eye blink inconsistency, micro-expression transitions
• Processing time: 2.1 seconds

File: sample_video.mp4
Analysis completed at: 2025-06-22 14:30:25
==================================================

This is a demonstration of the analysis output format.
In the real application, these results would be based on
actual model inference on uploaded video files.

Key Features of the Real Application:
✅ Load trained PyTorch models (.pth files)
✅ Process various video formats (MP4, AVI, MOV, etc.)
✅ Automatic face detection and cropping
✅ Real-time progress tracking
✅ Detailed confidence scores and explanations
✅ GPU acceleration support
✅ Cross-platform compatibility

Installation Instructions:
1. pip install -r requirements.txt
2. python deepfake_detector_gui.py
3. Load your trained model
4. Select video and analyze!
"""
        
        self.result_text.insert(tk.END, demo_result)

def main():
    """Run the demo GUI"""
    root = tk.Tk()
    app = DemoGUI(root)
    
    try:
        root.mainloop()
    except KeyboardInterrupt:
        print("\nDemo interrupted by user")

if __name__ == "__main__":
    main()
