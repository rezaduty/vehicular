#!/usr/bin/env python3
"""
Deepfake Detection GUI Application
Based on the 3D CNN temporal consistency analysis model from Paper.ipynb

This application provides a user-friendly interface for detecting de    def __init__(self, root):
        self.root = root
        self.root.title("Deepfake Detection in Social Media: A Temporal Artifact Analysis Using 3D Convolutional Neural Networks - UE University")
        
        # Make window responsive and set minimum size
        self.root.minsize(800, 600)
        self.root.geometry("1000x750")
        
        # Make window resizable and responsive
        self.root.rowconfigure(0, weight=1)
        self.root.columnconfigure(0, weight=1)kes
in uploaded video files using the trained temporal artifact analysis model.
"""

import os
import sys
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import threading
from pathlib import Path
import logging

# Try to import required dependencies
try:
    import cv2
    CV2_AVAILABLE = True
except ImportError:
    CV2_AVAILABLE = False

try:
    import torch
    import torchvision
    from torchvision import transforms
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False

try:
    import numpy as np
    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False

try:
    from PIL import Image
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DeepfakeDetectionModel:
    """3D CNN model for deepfake detection using temporal consistency analysis"""
    def __init__(self, num_classes=2):
        # Create the actual PyTorch module
        self.model = self._create_model(num_classes)
    
    def _create_model(self, num_classes):
        """Create the actual PyTorch model"""
        
        class _DeepfakeModel(torch.nn.Module):
            def __init__(self, num_classes):
                super(_DeepfakeModel, self).__init__()
                # Use a pre-trained 3D CNN as backbone
                self.backbone = torchvision.models.video.r3d_18(pretrained=False)
                
                # Replace the final fully connected layer for our binary classification task
                in_features = self.backbone.fc.in_features
                self.backbone.fc = torch.nn.Sequential(
                    torch.nn.Linear(in_features, 512),
                    torch.nn.ReLU(),
                    torch.nn.Dropout(0.5),
                    torch.nn.Linear(512, num_classes)
                )
            
            def forward(self, x):
                return self.backbone(x)
        
        return _DeepfakeModel(num_classes)
    
    def __getattr__(self, name):
        """Delegate attribute access to the underlying model"""
        return getattr(self.model, name)
    
    def __call__(self, *args, **kwargs):
        """Make the wrapper callable by delegating to the underlying model"""
        return self.model(*args, **kwargs)
    
    def forward(self, x):
        """Forward pass through the model"""
        return self.model(x)

class VideoProcessor:
    """Handles video preprocessing and frame extraction"""
    
    def __init__(self, clip_length=16, image_size=128, device='cpu'):
        self.clip_length = clip_length
        self.image_size = image_size
        self.device = device
        
        # Load face detector
        try:
            face_cascade_path = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
            self.face_detector = cv2.CascadeClassifier(face_cascade_path)
            if self.face_detector.empty():
                logger.warning("Failed to load face detector. Using full frames.")
                self.face_detector = None
        except Exception as e:
            logger.warning(f"Error loading face detector: {e}. Using full frames.")
            self.face_detector = None
    
    def extract_frames(self, video_path):
        """Extract frames from a video file"""
        frames = []
        cap = cv2.VideoCapture(video_path)

        # Get total frame count
        frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

        if frame_count <= 0:
            logger.error(f"Empty video or video read error: {video_path}")
            return None

        # Determine how to sample frames
        if frame_count < self.clip_length:
            # If video has fewer frames than clip_length, duplicate frames
            sample_indices = list(range(frame_count)) * (self.clip_length // frame_count + 1)
            sample_indices = sample_indices[:self.clip_length]
        else:
            # Sample frames at regular intervals
            sample_indices = np.linspace(0, frame_count - 1, self.clip_length, dtype=int)

        # Extract the sampled frames
        for idx in sample_indices:
            cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
            ret, frame = cap.read()

            if not ret:
                logger.warning(f"Failed to read frame {idx} from {video_path}")
                # Use a blank frame if reading fails
                frame = np.zeros((self.image_size, self.image_size, 3), dtype=np.uint8)
            else:
                # Face crop if enabled and face detector is available
                if self.face_detector is not None:
                    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                    faces = self.face_detector.detectMultiScale(gray, 1.3, 5)

                    if len(faces) > 0:
                        # Use the largest face
                        areas = [w*h for (x, y, w, h) in faces]
                        largest_face_idx = np.argmax(areas)
                        x, y, w, h = faces[largest_face_idx]

                        # Add margin to face crop
                        margin = 0.3  # 30% margin
                        x = max(0, int(x - margin * w))
                        y = max(0, int(y - margin * h))
                        w = min(frame.shape[1] - x, int(w * (1 + 2 * margin)))
                        h = min(frame.shape[0] - y, int(h * (1 + 2 * margin)))

                        frame = frame[y:y+h, x:x+w]

                # Resize to target size
                frame = cv2.resize(frame, (self.image_size, self.image_size))

                # Convert BGR to RGB
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

            frames.append(frame)

        cap.release()
        return np.array(frames)
    
    def preprocess_frames(self, frames):
        """Preprocess frames for model input"""
        if frames is None:
            return None
            
        # Define transform (same as validation transform from notebook)
        transform = transforms.Compose([
            transforms.Resize(int(self.image_size * 1.1)),
            transforms.CenterCrop(self.image_size),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        
        # Apply transforms to each frame
        transformed_frames = []
        for frame in frames:
            # Convert numpy array to PIL Image
            frame_pil = Image.fromarray(frame)
            transformed_frame = transform(frame_pil)
            transformed_frames.append(transformed_frame)

        # Stack frames along a new dimension
        frames_tensor = torch.stack(transformed_frames)
        # Reshape to [C, T, H, W] format expected by 3D CNN
        frames_tensor = frames_tensor.permute(1, 0, 2, 3)
        
        # Add batch dimension [1, C, T, H, W]
        frames_tensor = frames_tensor.unsqueeze(0)
        
        return frames_tensor

class DeepfakeDetectorGUI:
    """Main GUI application for deepfake detection"""
    
    def __init__(self, root):
        self.root = root
        self.root.title("Deepfake Detection in Social Media: A Temporal Artifact Analysis Using 3D Convolutional Neural Networks - UE University")
        self.root.geometry("1000x750")
        
        # Modern dark theme colors with glassmorphism
        self.colors = {
            'bg_dark': '#0d1117',
            'bg_secondary': '#161b22',
            'bg_tertiary': '#21262d',
            'glass_bg': '#1c2128',  # Slightly lighter for glass effect
            'glass_border': '#30363d',
            'accent_blue': '#58a6ff',
            'accent_green': '#3fb950',
            'accent_red': '#f85149',
            'accent_orange': '#ff8c00',
            'accent_purple': '#bc8cff',
            'text_primary': '#f0f6fc',
            'text_secondary': '#8b949e',
            'text_muted': '#6e7681',
            'border': '#30363d',
            'hover': '#2d333b'
        }
        
        self.root.configure(bg=self.colors['bg_dark'])
        
        # Configure ttk style for dark theme
        self.setup_dark_theme()
        
        # Initialize components
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.model = None
        self.video_processor = VideoProcessor(device=self.device)
        self.model_loaded = False
        self.is_pretrained_model = False
        
        # Create GUI elements
        self.create_widgets()
        
        # Try to load model automatically
        self.auto_load_model()
    
    def setup_dark_theme(self):
        """Configure basic dark theme"""
        # Keep it simple - just set the color scheme
        # Complex ttk styling can cause compatibility issues
        pass

    def create_modern_button(self, parent, text, command, accent_color, width=200, height=40):
        """Create a glassmorphism styled button"""
        button_frame = tk.Frame(parent, bg=self.colors['bg_secondary'])
        
        # Create glass effect container
        glass_frame = tk.Frame(
            button_frame,
            bg=self.colors['glass_bg'],
            relief='ridge',
            bd=1,
            highlightbackground=self.colors['glass_border'],
            highlightthickness=1
        )
        glass_frame.pack(pady=5, padx=2)
        
        button = tk.Button(
            glass_frame,
            text=text,
            command=command,
            font=('Segoe UI', 11, 'bold'),
            bg=accent_color,
            fg='#000000',  # Black text for visibility
            activebackground=self.lighten_color(accent_color),
            activeforeground='#000000',
            relief='flat',
            borderwidth=0,
            padx=25,
            pady=10,
            cursor='hand2'
        )
        
        # Add glassmorphism hover effects
        def on_enter(e):
            button.configure(
                bg=self.lighten_color(accent_color),
                fg='#000000'
            )
            glass_frame.configure(highlightbackground=accent_color)
        
        def on_leave(e):
            button.configure(
                bg=accent_color,
                fg='#000000'
            )
            glass_frame.configure(highlightbackground=self.colors['glass_border'])
        
        button.bind('<Enter>', on_enter)
        button.bind('<Leave>', on_leave)
        
        button.pack(fill='both', expand=True)
        return button_frame, button
    
    def lighten_color(self, color):
        """Lighten a hex color for hover effects"""
        # Simple color lightening - increase each RGB component
        color = color.lstrip('#')
        rgb = tuple(int(color[i:i+2], 16) for i in (0, 2, 4))
        lightened = tuple(min(255, int(c * 1.2)) for c in rgb)
        return f"#{''.join(f'{c:02x}' for c in lightened)}"

    def create_card_frame(self, parent, title=None, pady=10):
        """Create a glassmorphism card-style frame"""
        # Outer container for shadow effect
        shadow_frame = tk.Frame(parent, bg=self.colors['bg_dark'])
        shadow_frame.pack(pady=pady, padx=20, fill='x')
        
        # Main card with glassmorphism effect
        card = tk.Frame(
            shadow_frame, 
            bg=self.colors['glass_bg'],
            relief='ridge',
            bd=1,
            highlightbackground=self.colors['glass_border'],
            highlightthickness=1
        )
        card.pack(fill='x', padx=2, pady=2)
        
        content_frame = tk.Frame(card, bg=self.colors['glass_bg'])
        content_frame.pack(fill='both', expand=True, padx=20, pady=20)
        
        if title:
            title_label = tk.Label(
                content_frame,
                text=title,
                font=('Segoe UI', 14, 'bold'),
                bg=self.colors['glass_bg'],
                fg=self.colors['text_primary']
            )
            title_label.pack(anchor='w', pady=(0, 15))
        
        return content_frame
    
    def create_widgets(self):
        """Create and layout GUI widgets with modern dark theme and responsive design"""
        # Create main scrollable container for better small screen support
        self.canvas = tk.Canvas(self.root, bg=self.colors['bg_dark'], highlightthickness=0)
        self.scrollbar = ttk.Scrollbar(self.root, orient="vertical", command=self.canvas.yview)
        self.scrollable_frame = tk.Frame(self.canvas, bg=self.colors['bg_dark'])
        
        # Configure scrolling
        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )
        
        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        
        # Pack scrollable container
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")
        
        # Create main container with padding
        main_container = tk.Frame(self.scrollable_frame, bg=self.colors['bg_dark'])
        main_container.pack(fill='both', expand=True, padx=20, pady=20)
        main_container.columnconfigure(0, weight=1)
        
        # Header section with glassmorphism
        header_frame = tk.Frame(main_container, bg=self.colors['bg_dark'])
        header_frame.pack(fill='x', pady=(0, 30))
        header_frame.columnconfigure(1, weight=1)
        
        # App icon with glassmorphism effect
        icon_container = tk.Frame(header_frame, bg=self.colors['bg_dark'])
        icon_container.grid(row=0, column=0, sticky='w', padx=(0, 20))
        
        icon_frame = tk.Frame(
            icon_container, 
            bg=self.colors['accent_purple'], 
            width=60, 
            height=60,
            relief='flat',
            bd=0,
            highlightbackground=self.colors['glass_border'],
            highlightthickness=1
        )
        icon_frame.pack()
        icon_frame.pack_propagate(False)
        
        icon_label = tk.Label(
            icon_frame,
            text="🎭",
            font=('Segoe UI', 24),
            bg=self.colors['accent_purple'],
            fg='#000000'
        )
        icon_label.pack(expand=True)
        
        # Title section with modern typography
        title_container = tk.Frame(header_frame, bg=self.colors['bg_dark'])
        title_container.grid(row=0, column=1, sticky='ew')
        
        # Main title
        title_label = tk.Label(
            title_container,
            text="Deepfake Detection in Social Media: A Temporal",
            font=('Segoe UI', 20, 'bold'),
            bg=self.colors['bg_dark'],
            fg=self.colors['text_primary'],
            wraplength=600
        )
        title_label.pack(anchor='w')
        
        # Subtitle line 1
        subtitle1_label = tk.Label(
            title_container,
            text="Artifact Analysis Using 3D Convolutional Neural",
            font=('Segoe UI', 20, 'bold'),
            bg=self.colors['bg_dark'],
            fg=self.colors['text_primary'],
            wraplength=600
        )
        subtitle1_label.pack(anchor='w', pady=(2, 0))
        
        # Subtitle line 2
        subtitle2_label = tk.Label(
            title_container,
            text="Networks - UE University",
            font=('Segoe UI', 20, 'bold'),
            bg=self.colors['bg_dark'],
            fg=self.colors['text_primary'],
            wraplength=600
        )
        subtitle2_label.pack(anchor='w', pady=(2, 0))
        
        # Description
        desc_label = tk.Label(
            title_container,
            text="Advanced deepfake detection using temporal consistency analysis",
            font=('Segoe UI', 11, 'italic'),
            bg=self.colors['bg_dark'],
            fg=self.colors['accent_blue']
        )
        desc_label.pack(anchor='w', pady=(5, 0))
        
        # Responsive content layout
        self.content_container = tk.Frame(main_container, bg=self.colors['bg_dark'])
        self.content_container.pack(fill='both', expand=True, pady=(20, 0))
        self.content_container.columnconfigure(0, weight=1)
        self.content_container.columnconfigure(1, weight=1)
        
        # Left column - Controls
        self.left_column = tk.Frame(self.content_container, bg=self.colors['bg_dark'])
        self.left_column.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        self.left_column.columnconfigure(0, weight=1)
        
        # Right column - Results  
        self.right_column = tk.Frame(self.content_container, bg=self.colors['bg_dark'])
        self.right_column.grid(row=0, column=1, sticky="nsew", padx=(10, 0))
        self.right_column.columnconfigure(0, weight=1)
        self.right_column.rowconfigure(1, weight=1)
        
        # Create control sections in left column
        self.create_control_sections()
        
        # Create results section in right column
        self.create_results_section()
        
        # Bind mouse wheel to canvas for scrolling
        self.canvas.bind_all("<MouseWheel>", self._on_mousewheel)
        self.canvas.bind_all("<Button-4>", self._on_mousewheel)
        self.canvas.bind_all("<Button-5>", self._on_mousewheel)
        
        # Bind window resize for responsive behavior
        self.root.bind('<Configure>', self.on_window_resize)
        
    def _on_mousewheel(self, event):
        """Handle mouse wheel scrolling"""
        if event.num == 4 or event.delta > 0:
            self.canvas.yview_scroll(-1, "units")
        elif event.num == 5 or event.delta < 0:
            self.canvas.yview_scroll(1, "units")
    
    def on_window_resize(self, event):
        """Handle window resize for responsive layout"""
        if event.widget == self.root:
            window_width = self.root.winfo_width()
            
            # Switch to single column layout for small screens
            if window_width < 1000:
                self.right_column.grid_forget()
                self.right_column.grid(row=1, column=0, columnspan=2, sticky="nsew", padx=0, pady=(20, 0))
                self.content_container.columnconfigure(1, weight=0)
            else:
                self.right_column.grid_forget()
                self.right_column.grid(row=0, column=1, sticky="nsew", padx=(10, 0))
                self.content_container.columnconfigure(1, weight=1)
    
    def create_control_sections(self):
        """Create the control sections (model, video, analysis)"""
        # Model status card
        model_frame = self.create_card_frame(self.left_column, "🔧 Model Configuration")
        
        self.model_status_label = tk.Label(
            model_frame,
            text="● Model Status: Not Loaded",
            font=('Segoe UI', 11),
            bg=self.colors['glass_bg'],
            fg=self.colors['accent_red']
        )
        self.model_status_label.pack(anchor='w', pady=(0, 15))
        
        # Load model button with glassmorphism
        load_model_frame, self.load_model_btn = self.create_modern_button(
            model_frame, "📁 Load Model", self.load_model, self.colors['accent_blue']
        )
        load_model_frame.pack(anchor='w')
        
        # File selection card
        file_frame = self.create_card_frame(self.left_column, "📹 Video Selection")
        
        self.file_label = tk.Label(
            file_frame,
            text="No video file selected",
            font=('Segoe UI', 11),
            bg=self.colors['glass_bg'],
            fg=self.colors['text_muted']
        )
        self.file_label.pack(anchor='w', pady=(0, 15))
        
        # File selection buttons container
        file_buttons_frame = tk.Frame(file_frame, bg=self.colors['glass_bg'])
        file_buttons_frame.pack(fill='x', pady=(0, 10))
        
        select_file_frame, self.select_file_btn = self.create_modern_button(
            file_buttons_frame, "📂 Select Video", self.select_video_file, self.colors['accent_green']
        )
        select_file_frame.pack(side='left', padx=(0, 15))
        
        # Analysis progress card
        progress_frame = self.create_card_frame(self.left_column, "⚡ Analysis Progress")
        
        # Progress bar with modern styling
        self.progress_var = tk.DoubleVar()
        self.progress_bar = ttk.Progressbar(
            progress_frame,
            variable=self.progress_var,
            maximum=100,
            length=300,
            style="Modern.Horizontal.TProgressbar"
        )
        self.progress_bar.pack(pady=(0, 15))
        
        # Analysis status
        self.progress_label = tk.Label(
            progress_frame,
            text="Ready for analysis",
            font=('Segoe UI', 10),
            bg=self.colors['glass_bg'],
            fg=self.colors['text_secondary']
        )
        self.progress_label.pack(pady=(0, 15))
        
        # Analysis button
        analyze_frame, self.analyze_btn = self.create_modern_button(
            progress_frame, "� Analyze Video", self.analyze_video, self.colors['accent_orange']
        )
        analyze_frame.pack(anchor='w')
        
    def create_results_section(self):
        """Create the results section with better scrolling"""
        # Results card in right column
        results_frame = self.create_card_frame(self.right_column, "📊 Analysis Results")
        
        # Create text widget with scrollbar for results
        text_frame = tk.Frame(results_frame, bg=self.colors['glass_bg'])
        text_frame.pack(fill='both', expand=True)
        text_frame.columnconfigure(0, weight=1)
        text_frame.rowconfigure(0, weight=1)
        
        # Results text area with dark theme
        self.result_text = tk.Text(
            text_frame,
            wrap=tk.WORD,
            font=('Consolas', 10),
            bg=self.colors['bg_tertiary'],
            fg=self.colors['text_primary'],
            insertbackground=self.colors['accent_blue'],
            selectbackground=self.colors['accent_blue'],
            selectforeground=self.colors['bg_dark'],
            relief='flat',
            bd=0,
            padx=15,
            pady=15,
            height=15
        )
        self.result_text.grid(row=0, column=0, sticky='nsew')
        
        # Scrollbar for results
        result_scrollbar = ttk.Scrollbar(text_frame, orient="vertical", command=self.result_text.yview)
        self.result_text.configure(yscrollcommand=result_scrollbar.set)
        result_scrollbar.grid(row=0, column=1, sticky='ns')
        
        # Initial welcome message
        welcome_text = """🎭 Welcome to Deepfake Detection System

This advanced application uses 3D Convolutional Neural Networks for temporal artifact analysis to detect deepfake videos.

� Instructions:
1. Load a trained model (.pth file)
2. Select a video file to analyze
3. Run the analysis

🔬 Technical Details:
• Model: R3D-18 3D CNN architecture
• Analysis: Temporal consistency patterns
• Input: Video sequences (16 frames)
• Output: Confidence scores and detailed metrics

Ready to begin analysis..."""
        
        self.result_text.insert(tk.END, welcome_text)
        self.result_text.config(state=tk.DISABLED)
    
    def auto_load_model(self):
        """Try to automatically load a model from common locations"""
        possible_paths = [
            "models/best_deepfake_model.pth",
            "./best_deepfake_model.pth",
            "best_deepfake_model.pth",
            "../models/best_deepfake_model.pth"
        ]
        
        for path in possible_paths:
            if os.path.exists(path):
                try:
                    self.load_model_from_path(path)
                    break
                except Exception as e:
                    logger.warning(f"Failed to auto-load model from {path}: {e}")
                    continue
    
    def load_model(self):
        """Load a trained model file"""
        file_path = filedialog.askopenfilename(
            title="Select Model File",
            filetypes=[("PyTorch Models", "*.pth"), ("All Files", "*.*")]
        )
        
        if file_path:
            self.load_model_from_path(file_path)
    
    def load_model_from_path(self, file_path):
        """Load model from specified path"""
        try:
            self.progress_var.set("Loading model...")
            self.progress_bar.start()
            
            # Initialize model
            self.model = DeepfakeDetectionModel(num_classes=2)
            
            # Load state dict
            state_dict = torch.load(file_path, map_location=self.device)
            
            # Check if this is a pre-trained torchvision model or custom trained model
            is_pretrained = self._is_pretrained_model(state_dict)
            if is_pretrained:
                self._load_pretrained_weights(state_dict)
                model_type = "Pre-trained R3D-18 (backbone only)"
                self.is_pretrained_model = True
                warning_msg = ("\n⚠️  WARNING: This is a pre-trained model not specifically trained for deepfake detection.\n"
                              "The classification head has been randomly initialized.\n"
                              "Results may not be reliable for deepfake detection.\n"
                              "Please use a model trained specifically for this task.\n")
            else:
                # Try to load as custom trained model
                self.model.load_state_dict(state_dict)
                model_type = "Custom trained model"
                self.is_pretrained_model = False
                warning_msg = ""
            
            # Set to evaluation mode
            self.model.eval()
            self.model.to(self.device)
            
            self.model_loaded = True
            self.model_status_label.config(
                text=f"● Model Status: Loaded ({os.path.basename(file_path)})",
                fg=self.colors['accent_green']
            )
            
            self.progress_bar.stop()
            self.progress_var.set("Model loaded successfully")
            
            # Enable analyze button if video is selected
            if hasattr(self, 'selected_video_path'):
                self.analyze_btn.config(state='normal', bg=self.colors['accent_orange'], fg='#000000')
                
            self.update_results(f"✅ Model loaded successfully!\n"
                               f"📁 File: {file_path}\n"
                               f"🤖 Type: {model_type}\n"
                               f"🖥️  Device: {self.device}\n"
                               f"{warning_msg}"
                               f"🚀 Ready for analysis!\n"
                               f"───────────────────────────────────────────────────────────\n\n")
            
        except Exception as e:
            self.progress_bar.stop()
            self.progress_var.set("Failed to load model")
            messagebox.showerror("Error", f"Failed to load model:\n{str(e)}")
            logger.error(f"Model loading failed: {e}")
    
    def select_video_file(self):
        """Select a video file for analysis"""
        file_path = filedialog.askopenfilename(
            title="Select Video File",
            filetypes=[
                ("Video Files", "*.mp4 *.avi *.mov *.mkv *.wmv *.flv"),
                ("All Files", "*.*")
            ]
        )
        
        if file_path:
            self.selected_video_path = file_path
            filename = os.path.basename(file_path)
            self.file_label.config(text=f"✅ Selected: {filename}", fg=self.colors['accent_green'])
            
            # Enable analyze button if model is loaded
            if self.model_loaded:
                self.analyze_btn.config(state='normal', bg=self.colors['accent_orange'], fg='#000000')
            
            self.update_results(f"📹 Video selected: {filename}\n"
                               f"📁 Path: {file_path}\n"
                               f"───────────────────────────────────────────────────────────\n\n")
    
    def analyze_video(self):
        """Analyze the selected video for deepfakes"""
        if not self.model_loaded:
            messagebox.showerror("Error", "Please load a model first!")
            return
        
        if not hasattr(self, 'selected_video_path'):
            messagebox.showerror("Error", "Please select a video file first!")
            return
        
        # Run analysis in a separate thread to prevent GUI freezing
        analysis_thread = threading.Thread(target=self.run_analysis)
        analysis_thread.daemon = True
        analysis_thread.start()
    
    def run_analysis(self):
        """Run the deepfake detection analysis"""
        try:
            # Update GUI
            self.root.after(0, lambda: self.progress_var.set("Processing video..."))
            self.root.after(0, lambda: self.progress_bar.start())
            self.root.after(0, lambda: self.analyze_btn.config(state='disabled', bg=self.colors['bg_tertiary'], fg=self.colors['text_muted']))
            
            # Extract frames
            self.root.after(0, lambda: self.progress_var.set("Extracting frames..."))
            frames = self.video_processor.extract_frames(self.selected_video_path)
            
            if frames is None:
                self.root.after(0, lambda: self.show_error("Failed to extract frames from video"))
                return
            
            # Preprocess frames
            self.root.after(0, lambda: self.progress_var.set("Preprocessing frames..."))
            input_tensor = self.video_processor.preprocess_frames(frames)
            
            if input_tensor is None:
                self.root.after(0, lambda: self.show_error("Failed to preprocess frames"))
                return
            
            # Run inference
            self.root.after(0, lambda: self.progress_var.set("Running inference..."))
            input_tensor = input_tensor.to(self.device)
            
            with torch.no_grad():
                outputs = self.model(input_tensor)
                probabilities = torch.softmax(outputs, dim=1)
                _, predicted = torch.max(outputs, 1)
                
                # Get prediction results
                is_fake = predicted.item() == 1
                fake_probability = probabilities[0, 1].item()
                real_probability = probabilities[0, 0].item()
            
            # Update GUI with results
            self.root.after(0, lambda: self.display_results(
                is_fake, fake_probability, real_probability, frames.shape[0]
            ))
            
        except Exception as e:
            self.root.after(0, lambda: self.show_error(f"Analysis failed: {str(e)}"))
            logger.error(f"Analysis failed: {e}")
        
        finally:
            self.root.after(0, lambda: self.progress_bar.stop())
            self.root.after(0, lambda: self.analyze_btn.config(state='normal', bg=self.colors['accent_orange'], fg='#000000'))
    
    def display_results(self, is_fake, fake_prob, real_prob, num_frames):
        """Display analysis results"""
        # Determine confidence level
        confidence = max(fake_prob, real_prob)
        if confidence > 0.9:
            confidence_level = "Very High"
            confidence_emoji = "🔴"
        elif confidence > 0.8:
            confidence_level = "High"
            confidence_emoji = "🟠"
        elif confidence > 0.7:
            confidence_level = "Moderate"
            confidence_emoji = "🟡"
        else:
            confidence_level = "Low"
            confidence_emoji = "⚪"
        
        # Create results text with modern styling
        result_text = f"╔══════════════════════════════════════════════════════════╗\n"
        result_text += f"║                    ANALYSIS COMPLETE                    ║\n"
        result_text += f"╚══════════════════════════════════════════════════════════╝\n\n"
        
        if is_fake:
            result_text += f"🚨 DEEPFAKE DETECTED 🚨\n\n"
            result_text += f"🎯 Classification: FAKE\n"
            result_text += f"📊 Confidence: {confidence_level} ({fake_prob:.1%}) {confidence_emoji}\n\n"
        else:
            result_text += f"✅ AUTHENTIC VIDEO ✅\n\n"
            result_text += f"🎯 Classification: REAL\n"
            result_text += f"📊 Confidence: {confidence_level} ({real_prob:.1%}) {confidence_emoji}\n\n"
        
        result_text += f"📈 Detailed Probabilities:\n"
        result_text += f"   • ✅ Real: {real_prob:.1%}\n"
        result_text += f"   • 🚨 Fake: {fake_prob:.1%}\n\n"
        
        result_text += f"🔬 Technical Details:\n"
        result_text += f"   • 🎬 Frames processed: {num_frames}\n"
        result_text += f"   • 🧠 Model: 3D CNN (R3D-18)\n"
        result_text += f"   • ⚡ Method: Temporal consistency analysis\n"
        result_text += f"   • 🖥️  Device: {self.device}\n"
        
        # Add warning if using pre-trained model
        if self.is_pretrained_model:
            result_text += f"   • ⚠️  Model: Pre-trained (not deepfake-specific)\n"
        
        result_text += f"\n"
        
        # Add interpretation and recommendations
        if self.is_pretrained_model:
            result_text += f"\n⚠️  IMPORTANT: Pre-trained model detected!\n"
            result_text += f"   • This model was NOT trained for deepfake detection\n"
            result_text += f"   • Results are likely unreliable and should not be trusted\n"
            result_text += f"   • Please use a model specifically trained for deepfake detection\n"
            result_text += f"   • This is for demonstration purposes only\n\n"
        elif confidence < 0.7:
            result_text += f"\n💡 Note: Low confidence result. Consider:\n"
            result_text += f"   • Video quality may be too low\n"
            result_text += f"   • Insufficient facial content\n"
            result_text += f"   • Complex lighting conditions\n"
            result_text += f"   • Manual review recommended\n\n"
        elif is_fake and confidence > 0.8:
            result_text += f"\n⚠️  High confidence deepfake detection!\n"
            result_text += f"   • Consider reporting if harmful content\n"
            result_text += f"   • Verify with additional tools if needed\n"
            result_text += f"   • Be cautious with sensitive applications\n\n"
        elif not is_fake and confidence > 0.9:
            result_text += f"\n✅ High confidence authentic video\n"
            result_text += f"   • Video appears to be genuine\n"
            result_text += f"   • No significant temporal artifacts detected\n\n"
        
        result_text += f"📁 File: {os.path.basename(self.selected_video_path)}\n"
        result_text += f"🕒 Completed: {self.get_timestamp()}\n"
        result_text += f"════════════════════════════════════════════════════════════\n\n"
        
        self.update_results(result_text)
        self.progress_var.set("Analysis complete!")
    
    def show_error(self, message):
        """Show error message"""
        messagebox.showerror("Error", message)
        self.progress_var.set("Error occurred")
        self.update_results(f"❌ ERROR: {message}\n"
                           f"───────────────────────────────────────────────────────────\n\n")
    
    def update_results(self, text):
        """Update the results text area"""
        self.result_text.config(state=tk.NORMAL)
        self.result_text.insert(tk.END, text)
        self.result_text.see(tk.END)
        self.result_text.config(state=tk.DISABLED)
    
    def get_timestamp(self):
        """Get current timestamp"""
        from datetime import datetime
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def _is_pretrained_model(self, state_dict):
        """Check if the state dict is from a pre-trained torchvision model"""
        # Check for typical torchvision R3D model keys (without 'backbone.' prefix)
        pretrained_keys = ['stem.0.weight', 'layer1.0.conv1.0.weight', 'fc.weight']
        return any(key in state_dict for key in pretrained_keys)
    
    def _load_pretrained_weights(self, state_dict):
        """Load pre-trained weights into the backbone and initialize custom layers"""
        # Create a mapping from pretrained keys to our model keys
        backbone_state_dict = {}
        
        for key, value in state_dict.items():
            # Skip the original fc layer since we replaced it
            if key.startswith('fc.'):
                continue
            # Add 'backbone.' prefix to match our model structure
            new_key = f"backbone.{key}"
            backbone_state_dict[new_key] = value
        
        # Load the backbone weights (missing keys for custom fc layer is expected)
        missing_keys, unexpected_keys = self.model.load_state_dict(backbone_state_dict, strict=False)
        
        # Log what happened
        logger.info(f"Loaded pre-trained R3D-18 weights")
        logger.info(f"Missing keys (expected for custom classifier): {len(missing_keys)}")
        logger.info(f"Unexpected keys: {len(unexpected_keys)}")
        
        # Initialize the custom classification layers with random weights
        with torch.no_grad():
            if hasattr(self.model.model.backbone, 'fc'):
                for layer in self.model.model.backbone.fc:
                    if hasattr(layer, 'weight'):
                        torch.nn.init.xavier_uniform_(layer.weight)
                    if hasattr(layer, 'bias') and layer.bias is not None:
                        torch.nn.init.zeros_(layer.bias)

def main():
    """Main application entry point"""
    # Check for required dependencies using the availability flags
    missing_deps = []
    
    if not CV2_AVAILABLE:
        missing_deps.append("opencv-python")
        
    if not TORCH_AVAILABLE:
        missing_deps.append("torch")
        missing_deps.append("torchvision")
        
    if not NUMPY_AVAILABLE:
        missing_deps.append("numpy")
        
    if not PIL_AVAILABLE:
        missing_deps.append("pillow")

    if missing_deps:
        print("❌ Missing required dependencies:")
        for dep in missing_deps:
            print(f"   • {dep}")
        print("\n📦 Please install required packages:")
        print("   pip install -r requirements.txt")
        print("\n   Or install individually:")
        print("   pip install torch torchvision opencv-python pillow numpy")
        print("\n💡 See README_GUI.md for detailed setup instructions")
        
        # Try to show a simple tkinter message if possible
        try:
            root = tk.Tk()
            root.withdraw()  # Hide the root window
            messagebox.showerror(
                "Missing Dependencies", 
                f"Missing required packages:\n\n" + 
                "\n".join([f"• {dep}" for dep in missing_deps]) +
                "\n\nPlease run:\npip install -r requirements.txt"
            )
            root.destroy()
        except:
            pass
        
        sys.exit(1)
    
    # Check PyTorch functionality
    try:
        import torch
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        print(f"✅ PyTorch loaded successfully")
        print(f"🖥️  Device: {device}")
        if torch.cuda.is_available():
            print(f"🚀 GPU: {torch.cuda.get_device_name(0)}")
    except Exception as e:
        print(f"⚠️  PyTorch initialization warning: {e}")
    
    # Create and run the GUI application
    print("🚀 Starting Deepfake Detection GUI...")
    root = tk.Tk()
    
    try:
        app = DeepfakeDetectorGUI(root)
        print("✅ GUI initialized successfully")
        root.mainloop()
    except KeyboardInterrupt:
        print("\n🛑 Application interrupted by user")
    except Exception as e:
        print(f"❌ Application error: {e}")
        import traceback
        traceback.print_exc()
        
        # Try to show error in GUI if possible
        try:
            messagebox.showerror("Application Error", f"An error occurred:\n\n{str(e)}")
        except:
            pass

if __name__ == "__main__":
    main()
